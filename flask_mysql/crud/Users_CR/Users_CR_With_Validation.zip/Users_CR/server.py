from Flask_App.controllers import users
from Flask_App import app

if __name__=='__main__':
    app.run(debug=True)